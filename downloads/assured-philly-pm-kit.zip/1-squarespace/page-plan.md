# Page plan (Squarespace 7.1, Fluid Engine)

Brand colours, logo and copy come from the client's files. Every page gets its own SEO title,
description and social image. Every section gets a separate mobile arrangement in Fluid Engine.

## Header (all pages)
- Logo, navigation: Home · Services · Current Rentals · Contact.
- Native header button: **Tenant Portal**. Second button added by the snippet: **Owner Portal**.
- Until the portals exist, both link to short "Portal coming soon — contact us" pages. When AppFolio,
  Buildium or TenantCloud is chosen, swap the two links; nothing else changes.

## Footer (all pages)
- Licensed brokerage name and office phone exactly as registered (a slot to fill from the licence;
  Pennsylvania's advertising rules, 49 Pa. Code § 35.305, are about this. Confirm wording with the
  broker of record).
- Equal Housing Opportunity logo and statement.
- contact@ link, office address, privacy note for the forms.

## Home
- Hero: one line for owners, one for renters, two buttons (Owner inquiry · Current rentals).
- What we manage (service summary) → links into the Services tabs (/services#buy, #sell, #lease).
- Why owners choose us, neighbourhoods served, short process, testimonials only if they are real.
- Closing call to action → Contact / Owner Inquiry.

## Services
- Intro section, a short `service-tabs` section for the tab bar, then three sections with the anchors
  `buy`, `sell`, `lease`. Each is edited normally in Fluid Engine.
- Code: the footer snippet (dist/code-injection-footer.html).

## Current Rentals
- Now: a collection (one item per unit: photos, rent, beds/baths, neighbourhood, available date,
  "Request a showing"), shown with a Summary block so new units appear automatically.
- Later: replace that section with the listings feed of the chosen platform (AppFolio and Buildium
  both publish vacancies to an external website), so listings are entered once.
- On the page: a link to the written tenant screening criteria. Philadelphia's Renters' Access Act
  requires landlords to provide uniform screening criteria before accepting an application or fee,
  and the City's guidance tells landlords to "create and post" them; the rentals page is the natural
  place. (Content to come from the client; confirm with counsel.)

## Contact / Owner Inquiry
- Owner inquiry form (fields in owner-inquiry-form.md), general contact form, phone, map of service area.
- Storage: email to contact@ and, as a backup, a Google Sheet (Squarespace allows several storage
  options per form). Zapier storage can feed a CRM later.
