# Owner inquiry form (Squarespace Form block)

| Field | Type | Required | Why it is asked |
|---|---|---|---|
| Name | Name | yes | Reply and CRM record |
| Email | Email | yes | Reply |
| Phone | Phone | no | Call-back option |
| Property address | Address | yes | Service-area and rent check |
| Property type | Dropdown: Single-family / Rowhome / Condo / 2–4 units / 5+ units | yes | Fee model and scope |
| Number of units | Number | yes | Fee model |
| Occupancy now | Radio: Vacant / Tenant in place / Owner-occupied | yes | Leasing vs takeover |
| What do you need? | Checkboxes: Full management / Leasing only / Sell / Buy | yes | Routes to the right service |
| Currently managed by | Radio: Self / Another company / Not yet rented | no | Transition planning |
| When do you want to start? | Dropdown: Now / 1–3 months / Just exploring | no | Priority |
| Anything else? | Text area | no | Context |

- Submit button: "Send owner inquiry".
- Post-submit message: "Thanks — we reply within one business day." (the client sets the promise).
- Storage: email → contact@assuredphillypm.com; Google Drive → "Owner inquiries" sheet as backup.
  Later: Zapier storage → CRM / OpenPhone (Quo) contact.
- Spam: turn on the form's reCAPTCHA option.
- Do not collect Social Security numbers, bank details or tenant personal data in this form.
