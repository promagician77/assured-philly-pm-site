# DNS records for assuredphillypm.com (Google Workspace + Squarespace)

Add these where the domain's DNS lives. If the domain was bought through Squarespace, that is
Squarespace → Domains → assuredphillypm.com → DNS → Custom records. Values are pasted without
quotes; Squarespace adds the domain to the host name for you.

The order matters because Google builds in two waits:

- Google: "after you turn on Gmail for your organization, you must wait 24–72 hours before you can
  get your DKIM key in the Admin console."
- Google: "Allow 48 hours after setting up SPF and/or DKIM before setting up DMARC."

| Step | When | Type | Host | Value | Priority | What it does |
|---|---|---|---|---|---|---|
| 1 | Visit 1 | TXT | @ | `google-site-verification=…` (from the Admin console) | | Proves you own the domain (skip if already verified) |
| 2 | Visit 1 | MX | @ | `smtp.google.com` | 1 | Delivers mail for contact@ and info@ to Google. Delete every other MX record. |
| 3 | Visit 1 | TXT | @ | `v=spf1 include:_spf.google.com ~all` | | Authorises Google's servers to send as the domain. One SPF record only. |
| 4 | Visit 2 (24–72 h after Gmail is on) | TXT | google._domainkey | `v=DKIM1; k=rsa; p=…` (2048-bit, generated in Admin console → Apps → Google Workspace → Gmail → Authenticate email) | | Signs outgoing mail with your domain. Then click **Start authentication**. |
| 5 | Visit 3 (48 h after steps 3–4) | TXT | _dmarc | `v=DMARC1; p=none; rua=mailto:dmarc@assuredphillypm.com` | | Tells receivers what to do with failures and sends you reports. Create dmarc@ as a group or alias first, or the reports bounce. |

## Website records (only if the domain is registered somewhere other than Squarespace)

| Type | Host | Value |
|---|---|---|
| A | @ | 198.185.159.144 |
| A | @ | 198.185.159.145 |
| A | @ | 198.49.23.144 |
| A | @ | 198.49.23.145 |
| CNAME | www | ext-cust.squarespace.com |
| CNAME | (unique code from Squarespace) | verify.squarespace.com |

## Rules that keep it working later

- **One SPF record.** When AppFolio, Buildium, a CRM or an email tool needs to send as the domain,
  add its `include:` to the existing record. A second `v=spf1` record makes SPF fail for every message
  (RFC 7208). The live check counts how many of the 10 allowed DNS lookups are used.
- **Never delete the DKIM record** while Gmail is signing with it.
- **Move DMARC from p=none to quarantine/reject only after reading the reports**, so a forgotten sender
  (for example form notifications from a tool) is not blocked.

## How to confirm (visit 3)

1. Run the live check on the demo site: every row should be green.
2. Send a message from contact@ to a personal Gmail address, open it, ⋮ → **Show original**:
   SPF, DKIM and DMARC should all read **PASS**.
