# Google Workspace finish-up runbook

Super-admin access to admin.google.com and edit access to the domain's DNS are needed.

## Visit 1

1. **Domain verified?** Admin console → Account → Domains → Manage domains. If not verified, add the
   TXT record Google shows (records.md, step 1).
2. **MX.** Add `MX @ smtp.google.com` priority 1 and delete any other MX records. In the Admin console,
   click **Activate Gmail**. (Note the time: the DKIM wait starts here.)
3. **SPF.** Add `TXT @ v=spf1 include:_spf.google.com ~all`. Check there is no second `v=spf1` record.
4. **contact@ and info@.** Decide per address:
   - **Alias on a user** (Directory → Users → user → Add alternate emails): mail lands in one person's
     inbox. Up to 30 aliases per user, no extra licence.
   - **Google Group** (Directory → Groups): several people see and answer the mail. Use this if more than
     one person will answer owner inquiries.
5. **Reply from the role address.** In Gmail → Settings → Accounts → **Send mail as** → Add another
   email address → contact@assuredphillypm.com (tick "Treat as an alias"). Without this, replies leave
   from the person's own address.
6. **Test incoming.** From a personal Gmail, write to contact@ and info@; both must arrive.

## Visit 2 (24–72 hours after Gmail was activated)

7. Admin console → Apps → Google Workspace → Gmail → **Authenticate email** → Generate new record →
   2048-bit, selector `google`.
8. Add the TXT record at `google._domainkey`, wait until the live check shows it, then click
   **Start authentication**. (Google says DKIM can take up to 48 hours to start working.)

## Visit 3 (48 hours after SPF and DKIM)

9. Create `dmarc@` (group or alias) so reports have somewhere to go.
10. Add `TXT _dmarc v=DMARC1; p=none; rua=mailto:dmarc@assuredphillypm.com`.
11. Send a test from contact@ to a personal Gmail; **Show original** must read SPF PASS, DKIM PASS,
    DMARC PASS. Screenshot it for the hand-over notes.

## Hand-over

- Who is super admin, and a second admin account for recovery.
- Where DNS is edited, with a screenshot of the final records.
- The rule: one SPF record; new senders are merged into it.
