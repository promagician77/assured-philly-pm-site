Assured Philly PM pre-build kit

1-squarespace/code-injection-footer.html
  Paste into Settings > Developer Tools > Code Injection > Footer (Core plan or higher).
  Buy / Sell / Lease tabs: give three sections the anchor links buy, sell, lease.
  Portal buttons: turn on the header button as "Tenant Portal"; the snippet adds "Owner Portal".
  Labels and links are set at the top of the file.

1-squarespace/page-plan.md, owner-inquiry-form.md
  What goes on each page, and the owner inquiry form fields.

2-email/records.md, workspace-runbook.md
  The DNS records in order, and the three-visit Google Workspace steps.
